#!/usr/bin/env python3

from brain_games.task import welcome_user

from brain_games.task import user_answer



def main():
  welcome_user()
  user_answer()


if __name__ == '__main__':
    main()
