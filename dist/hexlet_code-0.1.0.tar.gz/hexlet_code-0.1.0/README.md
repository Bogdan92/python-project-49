### Hexlet tests and linter status:
[![Actions Status](https://github.com/Bogdan92/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Bogdan92/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/5e8b9c5aa4f8ee2088ba/maintainability)](https://codeclimate.com/github/Bogdan92/python-project-49/maintainability)

[![Asciinema - Even](https://img.shields.io/badge/Asciinema%20--%20Even-White?style=flat&logo=Even&logoColor=White)](https://asciinema.org/a/D7QPJIhSQ1UapbFqmzEpKpgJu)

[![Asciinema - Calc](https://img.shields.io/badge/Asciinema%20--%20Calc-White?style=flat&logo=Even&logoColor=White)](https://asciinema.org/a/Fqmomm7OIaoL86P8ppc9TbNHi)
